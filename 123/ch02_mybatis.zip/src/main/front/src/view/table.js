import React, {  } from 'react';

function Table() {
  return (
    <div>
      <h1>게시판</h1>
    </div>
  )
}
export default Table;