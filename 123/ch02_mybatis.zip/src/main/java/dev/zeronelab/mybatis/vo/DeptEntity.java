package dev.zeronelab.mybatis.vo;

import lombok.Data;

@Data
public class DeptEntity {
	Integer deptno;
	String dname;
	String loc;
}
