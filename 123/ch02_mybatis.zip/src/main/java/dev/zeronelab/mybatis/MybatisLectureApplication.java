package dev.zeronelab.mybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisLectureApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisLectureApplication.class, args);
	}

}
