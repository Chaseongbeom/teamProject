package dev.zeronelab.mybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisLectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
